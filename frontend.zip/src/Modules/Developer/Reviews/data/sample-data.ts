export const sampleReviewData = [
    {
      taskName: "Implement Authentication Module",
      isRated: true,
      review: "The module was implemented perfectly and on time.",
      rating: 5,
      date: "2024-06-01",
    },
    {
      taskName: "Design User Dashboard",
      isRated: false,
    },
    {
      taskName: "Fix Bugs in Payment System",
      isRated: true,
      review: "Fixed the critical bugs, but some minor issues remain.",
      rating: 3,
      date: "2024-05-25",
    },
  ];