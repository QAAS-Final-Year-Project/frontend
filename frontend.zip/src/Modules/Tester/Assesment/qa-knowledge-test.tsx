import { FC } from "react";


const QAKnowledgeTest: FC<{data:any}> = ({data}) => {
    return <div></div>
}

export default QAKnowledgeTest;