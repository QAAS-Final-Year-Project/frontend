import { FC } from 'react'

interface TableComponentProps {
  
}

const TableComponent: FC<TableComponentProps> = () => {
  return (
    <div>
      Table Component
    </div>
  )
}

export default TableComponent