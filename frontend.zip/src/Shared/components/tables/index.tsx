export { default as TableComponent } from "./table";
// export {default as MiniTableComponent} from "./mini-table"
export { default as Shimmers } from "./shimmers";
