// import { FC, useCallback, useEffect } from "react";
// import { usePagination } from "react-use-pagination";
// import TableBodyComponent from "./table-body";
// import TableFooterComponent from "./table-footer";

// interface MiniTableComponentProps<TData = any> {
//   data: {
//     rows: TData[];
//     total: number;
//     page: number;
//     pageSize: number;
//     totalPages: number;
//   };
//   loading?: boolean;
//   renderColumns?: FC<TData>;
//   renderItem?: FC<TData>;
//   renderLoader?: FC;
// }

// const MiniTableComponent: FC<MiniTableComponentProps> = ({
//   loading,
//   renderColumns,
//   renderItem,
//   renderLoader,
//   data,
// }) => {
//   return (
//     <div className=''>
//       <TableBodyComponent
//         data={data}
//         loading={loading}
//         renderColumns={renderColumns}
//         renderLoader={renderLoader}
//         renderItem={renderItem}
//       />
//       <TableFooterComponent noBorder={true} data={data} />
//     </div>
//   );
// };

// export default MiniTableComponent;


export {}